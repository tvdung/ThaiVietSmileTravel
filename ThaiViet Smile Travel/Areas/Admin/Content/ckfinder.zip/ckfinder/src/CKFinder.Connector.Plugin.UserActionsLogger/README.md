# CKFinder UserActionsLogger Plugin Sample

This sample plugin [illustrates the usage of CKFinder events](http://docs.cksource.com/ckfinder3-net/howto.html#howto_logging_actions) to log selected user actions.

## Configuration Options

This plugin doesn't support any options.

All logs are directed to the default CKFinder logger.
